from setuptools import setup
from setuptools.dist import Distribution
from setuptools.command.sdist import sdist

dist = Distribution({'name': 'palvi_calculator', 'version': '1.0.0'}) # etc.
dist.script_name = 'setup.py'
cmd = sdist(dist)
cmd.ensure_finalized()
cmd.run()  # TODO: error handling
with open("README.txt", 'r') as f:
    long_description = f.read()

setup(
   name='palvi_calculator',
   version='0.0.1',
   description='A Very Bascic Calculator',
   license="MIT",
   long_description=long_description,
   author='palvi pawar',
   author_email='palvimail@gmail.com',
   url="",
   packages=['palvi_calculator'],  #same as name
   install_requires=[''] #external packages as dependencies

)